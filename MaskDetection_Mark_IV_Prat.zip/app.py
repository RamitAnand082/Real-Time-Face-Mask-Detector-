from flask import Flask, render_template, Response, request, jsonify, make_response, redirect, send_file
from camera import Video
import pandas as pd
import uuid
from flask_socketio import SocketIO
import asyncio
import time

app=Flask(__name__)
socketio = SocketIO(app)

@app.route("/")
def default():
    return redirect("/home")

@app.route('/login')
def login():
    return render_template('loginpage.html')

@app.route('/logout')
def logout():
    resp = make_response("ok")
    resp.set_cookie("usertk", '', max_age= -1, path= "/", httponly= True)
    return resp

@app.route('/logme', methods=['POST'])
def logme():
    userData = request.get_json()
    users = pd.read_csv("users.csv")

    if userData['email'] in users['email'].values:
        if userData['password'] in users['password'].values:
            spUser = users[users['email'] == userData['email']].index[0]
            print(spUser)
            if users.loc[spUser]['email'] == userData['email'] and users.loc[spUser]['password'] == userData['password']:
                resp = jsonify({
                    'isSuccess': True
                })
                resp.set_cookie("usertk", users.loc[spUser]['serve'],  max_age= 14*24*60*60, path= "/", httponly= True)
                return resp
            else:
                return jsonify({
                    'isSuccess': False,
                    'msg': "Wrong Password"
                })
        else:
            return jsonify({
                'isSuccess': False,
                'msg': "Wrong Password"
            })
    else:
        return jsonify({
            'isSuccess': False,
            'msg': "No user user, Try Signing Up!"
        })
            
@app.route('/signup')
def signup():
    return render_template('signup.html')

@app.route('/addme', methods=['POST'])
def addMe():
    dataRec = request.get_json()
    users = pd.read_csv("users.csv")

    if dataRec['email'] in users['email'].values:
        resp = {
            'isSuccess': False,
            'msg': "user already exists!"
        }
        return jsonify(resp)
    else:
        tk = f"""{dataRec['email'].split("@")[0]}.{uuid.uuid4()}"""
        users.loc[len(users.index)] = [dataRec['name'], dataRec['email'], dataRec['password'], tk]
        users.to_csv("users.csv", index= False)
        resp = {
            'isSuccess': True
        }

        jResp = jsonify(resp)
        jResp.set_cookie("usertk", tk, max_age= 14*24*60*60, path= "/", httponly= True)
        return jResp

@app.route('/home')
def index():
    userTk = request.cookies.__contains__("usertk")
    print(userTk)
    if userTk:
        userTk = request.cookies['usertk']
        users = pd.read_csv("users.csv")
        hasUser = False
        for mail in users['email']:
            if mail.split("@")[0] == userTk.split(".")[0]:
                hasUser = True
                print("Found")
                break
        
        if hasUser and (userTk in users['serve'].values):
            return render_template('index.html')
        else:
            print("No User token")
            return redirect("/login")
    else:
        print("No token")
        return redirect("/login")


@socketio.on('connect')
def sCon(dd):
    global videoObj
    videoObj = Video()
    print("connected...")
    # asyncio.create_task(checkCon())



@socketio.on('aliveLine')
def aliveLine(data):
    global lastBeat
    lastBeat = time.time()
    print("Alive Beat...")


def gen(camera):
    while True:
        frame=camera.get_frame(socketio)
        yield(b'--frame\r\n'
       b'Content-Type:  image/jpeg\r\n\r\n' + frame +
         b'\r\n\r\n')

@app.route('/video')
def video():
    return Response(gen(Video()),
    mimetype='multipart/x-mixed-replace; boundary=frame')


app.run(debug=True, host= "0.0.0.0")