import cv2
from keras.models import load_model
import numpy as np
import pygame

np.set_printoptions(suppress= True)

faceDetect=cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
model = load_model('mask_mark_IV.h5', compile= False)

class_names = open("labels.txt", "r").readlines()

isAlarmOnFire = False

def processFrame(frame):
    global isAlarmOnFire
    # Resize the raw image into (224-height,224-width) pixels
    frame = cv2.resize(frame, (224, 224), interpolation=cv2.INTER_AREA)

    # Make the image a numpy array and reshape it to the models input shape.
    frame = np.asarray(frame, dtype=np.float32).reshape(1, 224, 224, 3)

    # Normalize the image array
    frame = (frame / 127.5) - 1

    # Predicts the model
    prediction = model.predict(frame)
    index = np.argmax(prediction)
    class_name = class_names[index]

    # confidence_score = prediction[0][index]
    # print("Prediction: ", prediction, end="")
    # print("\nClassName: ", class_name, end=" ")
    # print("\Conf: ", confidence_score, end="\n================\n\n")

    return class_name[2]

class Video(object):

    def onDiconnect(self):
        pygame.mixer.music.stop()
        self.video.release()
        cv2.destroyAllWindows()
        print("Disconnected Camera and Music")

    def __init__(self):
        self.video=cv2.VideoCapture(0)
        
    def __del__(self):
        self.video.release()

    def get_frame(self, sk):
        ret,frame=self.video.read()

        faces=faceDetect.detectMultiScale(frame, 1.3, 5)
        sk.emit("processedFrame", processFrame(frame).lower())
        for x,y,w,h in faces:
            x1,y1=x+w, y+h
            cv2.rectangle(frame, (x,y), (x+w, y+h), (255,0,255), 1)
            cv2.line(frame, (x,y), (x+30, y),(255,0,255), 6) #Top Left
            cv2.line(frame, (x,y), (x, y+30),(255,0,255), 6)

            cv2.line(frame, (x1,y), (x1-30, y),(255,0,255), 6) #Top Right
            cv2.line(frame, (x1,y), (x1, y+30),(255,0,255), 6)

            cv2.line(frame, (x,y1), (x+30, y1),(255,0,255), 6) #Bottom Left
            cv2.line(frame, (x,y1), (x, y1-30),(255,0,255), 6)

            cv2.line(frame, (x1,y1), (x1-30, y1),(255,0,255), 6) #Bottom right
            cv2.line(frame, (x1,y1), (x1, y1-30),(255,0,255), 6)
        ret,jpg=cv2.imencode('.jpg',frame)
        return jpg.tobytes()